#Creates integration layer

import asyncio 
import json
import time 
import websockets
from cancel_window.simple_cancel_window import SimpleCancelWindow
from market_data.orderbook import OrderBook #Your OrderBook class 
from alpha_scoring.alpha_pipeline import AlphaSignalPipeline
from dynamic_risk_engine.throttle_cooldown_manager import AsyncThrottleCooldownManager

BINANCE_WS_URL = "wss://stream.binance.com:9443/stream"

class BinanceCancelWindowRunner:
    def __init__(self, symbol: str = 'btcusdt'):
        self.symbol = symbol.lower()
        self.cancel_window = SimpleCancelWindow()
        self.orderbook = OrderBook(self.symbol.upper()) # Inject real-time book
        self.cancel_window.orderbook = self.orderbook
        self.ws = None 
        self.last_density_check = 0
        self.enable_diagnostics = True
        self.alpha_pipeline = AlphaSignalPipeline()

    async def connect(self):
        streams = f"{self.symbol}@depth@1000ms/{self.symbol}@trade"
        uri = f"{BINANCE_WS_URL}?streams={streams}"
        self.ws = await websockets.connect(uri, ping_interval = 15, ping_timeout=10)
        print(f"Connected to Binance Websocket: {self.symbol}")


    async def run(self, flag_limit: int = 20):
        """
        flag limit set to 20 for demo, you can change it later in production
        this is just a safe guard
        """
        flag_count = 0
        assert self.ws is not None, "WebSocket not Connected"

        async for raw_msg in self.ws:
            msg = json.loads(raw_msg)
            stream = msg['stream']
            data = msg['data']

            if stream.endswith("depth@1000ms"):
                self.orderbook.update(data) # (Optional if orderbook supports it)
                self.cancel_window.process_l2_update(data)

            elif stream.endswith("trade"):
                self.cancel_window.process_trade(data)


           
            flags = self.cancel_window.flush_flags()
            #self.alpha_pipeline.update_market(int(time.time()* 1000),{
            #    'orderbook': self.orderbook,  #if needed by age/layering scorers
            #    'flags': flags
            #})
            #signal = self.alpha_pipeline.get_alpha_signal(int(time.time() * 1000))
            #print(f"[Alpha Signal Score]: {signal}")


            
             #Process emitted flags
            current_ts = int(time.time() * 1000)
            if flags:
                #Ensure all flags have a side
                for flag in flags:
                    flag.setdefault('side', 'ask')

                self.alpha_pipeline.update_market(current_ts,{
                    'orderbook': self.orderbook,
                    'flag': flags #Pass Entire batch
                })

                signal = self.alpha_pipeline.get_alpha_signal(current_ts)
                print(f"[Alpha Signal Score]: {signal}")
                print(f"Flags:  {flags}")
                flag_count += len(flags)

                if flag_count >= flag_limit:
                    print("Flag limit reached.")
                    return
            if self.enable_diagnostics and time.time() - self.last_density_check > 3:
                print("[System State]", self.cancel_window.snapshot_state())
                print("[Cancel Density Summary]", self.cancel_window.get_normalized_cancel_density())
                print("Bid Cancel Heatmap", self.cancel_window.get_cancel_density("bid"))
                print("Ask Cancel Heatmap", self.cancel_window.get_cancel_density("ask"))
                self.last_density_check = time.time()


                
    async def close(self):
        if self.ws:
            await self.ws.close()
            print("WebSocket connection closed")




if __name__ == "__main__":
    async def main():
        runner = BinanceCancelWindowRunner('btcusdt')
        await runner.connect()
        await runner.run(flag_limit=9)
        await runner.close()

    asyncio.run(main())