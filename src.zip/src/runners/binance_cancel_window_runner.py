#Creates integration layer
import os
from dotenv import load_dotenv
import asyncio 
import json
import time 
import websockets


#Core modules
from cancel_window.simple_cancel_window import SimpleCancelWindow
from market_data.orderbook import OrderBook #Your OrderBook class 
from alpha_scoring.alpha_pipeline import AlphaSignalPipeline

#Risk and performance tracking
from dynamic_risk_engine.throttle_cooldown_manager import AsyncThrottleCooldownManager
from dynamic_risk_engine.throttle_cooldown_manager import ThrottleCooldownManager
from dynamic_risk_engine.performance_tracker import PerformanceTracker


#Execution Layer
from Execution_layer.execution_coordinator import ExecutionCoordinator
from Execution_layer.binance_adapter import BinanceExecutionAdapter
from Execution_layer.mock_adapter import MockExchangeAdapter


#Load env variables from .env
load_dotenv()


# === config ====
SYMBOL = "BTCUSDT"
API_KEY = os.getenv("BINANCE_API_KEY")
API_SECRET =os.getenv("BINANCE_API_SECRET")
BINANCE_WS_URL = "wss://stream.binance.com:9443/stream"

class BinanceCancelWindowRunner:
    def __init__(self, symbol: str = 'btcusdt', api_key=None,
                 api_secret = None
                            ):
        """
        Initializes Instances and Required Keys
        Args:
            :param symbol: 'BTCUSDT'
            :param api_key: API_KEY
            :param api_secret: API_SECRET
        """
        
        #Core signal / Market modules
        self.symbol = symbol.lower()
        self.cancel_window = SimpleCancelWindow()
        self.orderbook = OrderBook(self.symbol.upper()) # Inject real-time book
        self.cancel_window.orderbook = self.orderbook
        self.alpha_pipeline = AlphaSignalPipeline()

        #Risk Modules and performance
        self.throttle_manager = ThrottleCooldownManager()
        self.performance_tracker = PerformanceTracker()

        #Execution Coordinator
        self.exec_coord = ExecutionCoordinator(
            alpha_pipeline = self.alpha_pipeline,
            throttle_manager = self.throttle_manager,
            performance_tracker = self.performance_tracker,  
            default_symbol = self.symbol.upper()
        )

        #Production adapter
        self.binance_adapter = BinanceExecutionAdapter(
            api_key = API_KEY,
            api_secret=API_SECRET,
            throttle_manager= self.throttle_manager,
            default_symbol=self.symbol.upper()

        )

        #Mock_adapter
        self.mockadapter = MockExchangeAdapter(
            instant_fill= True,
            throttle_manager= self.throttle_manager
        )

        #Step 4 - wire callbacks
        self.binance_adapter.on_fill_callback = self.exec_coord._on_fill
        self.mockadapter.on_fill_callback = self.exec_coord._on_fill



        #Netowrking
        self.ws = None 
        self.last_density_check = 0
        self.enable_diagnostics = True
      


    async def main(self):
        #Step 5 - Time sync (Important for Binance
        await self.binance_adapter.sync_sever_time()

        #Step 6 - Main Websocket Loop
        async for event in binance_websocket_listener(SYMBOL):
            if event['e'] == 'depthUpdate':
                order_book.update_from_event(event)

            elif event['e'] == 'ORDER_TRADE_UPDATE':
                #Pass user trade updates to adapter for fill handling
                await self.binance_adapter.handle_user_event(event)

            elif event['e'] == 'trade':
                #Register trade in alpha pipeline
                 self.alpha_pipeline.trade_event(event)

            #Step 7 - Decision to trade
            signal = alpha_pipeline.compute_signal()
            if signal.should_trade:
                order_details = self.exec_coord.decide_order(signal)
                await self.binance_adapter.place_order(**order_details)
            
            

    async def connect(self):
        streams = f"{self.symbol}@depth@1000ms/{self.symbol}@trade"
        uri = f"{BINANCE_WS_URL}?streams={streams}"
        self.ws = await websockets.connect(uri, ping_interval = 15, ping_timeout=10)
        print(f"Connected to Binance Websocket: {self.symbol}")


    async def run(self, flag_limit: int = 20):
        """
        flag limit set to 20 for demo, you can change it later in production
        this is just a safe guard
        """
        flag_count = 0
        assert self.ws is not None, "WebSocket not Connected"

        async for raw_msg in self.ws:
            msg = json.loads(raw_msg)
            stream = msg['stream']
            data = msg['data']

            if stream.endswith("depth@1000ms"):
                self.orderbook.update(data) # (Optional if orderbook supports it)
                self.cancel_window.process_l2_update(data)

            elif stream.endswith("trade"):
                self.cancel_window.process_trade(data)


           
            flags = self.cancel_window.flush_flags()
            #self.alpha_pipeline.update_market(int(time.time()* 1000),{
            #    'orderbook': self.orderbook,  #if needed by age/layering scorers
            #    'flags': flags
            #})
            #signal = self.alpha_pipeline.get_alpha_signal(int(time.time() * 1000))
            #print(f"[Alpha Signal Score]: {signal}")


            
             #Process emitted flags
            current_ts = int(time.time() * 1000)
            if flags:
                #Ensure all flags have a side
                for flag in flags:
                    flag.setdefault('side', 'ask')

                self.alpha_pipeline.update_market(current_ts,{
                    'orderbook': self.orderbook,
                    'flag': flags #Pass Entire batch
                })

                signal = self.alpha_pipeline.get_alpha_signal(current_ts)
                print(f"[Alpha Signal Score]: {signal}")
                print(f"Flags:  {flags}")
                flag_count += len(flags)

                if flag_count >= flag_limit:
                    print("Flag limit reached.")
                    return
            if self.enable_diagnostics and time.time() - self.last_density_check > 3:
                print("[System State]", self.cancel_window.snapshot_state())
                print("[Cancel Density Summary]", self.cancel_window.get_normalized_cancel_density())
                print("Bid Cancel Heatmap", self.cancel_window.get_cancel_density("bid"))
                print("Ask Cancel Heatmap", self.cancel_window.get_cancel_density("ask"))
                self.last_density_check = time.time()


                
    async def close(self):
        if self.ws:
            await self.ws.close()
            print("WebSocket connection closed")




if __name__ == "__main__":
    async def main():
        runner = BinanceCancelWindowRunner('btcusdt')
        await runner.connect()
        await runner.run(flag_limit=9)
        await runner.close()

    asyncio.run(main())